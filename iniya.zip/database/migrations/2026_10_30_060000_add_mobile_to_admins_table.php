<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (! Schema::hasColumn('admins', 'mobile')) {
            Schema::table('admins', function (Blueprint $table) {
                $table->string('mobile', 25)->nullable()->after('email')->index();
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('admins', function (Blueprint $table) {
            $table->dropIndex(['mobile']);
            $table->dropColumn('mobile');
        });
    }
};
